# BEZUBAAN Saathi — connected setup

The website (GitHub Pages) sends every report, dispatch and resolve to `api.py`,
which calls the functions in `backend7.py`. All data is stored in `saathi.db`,
the same database the Streamlit app (`app.py`) uses.

```
api.py            # small server: website -> backend7 functions
backend7.py       # the team's backend (AI model line + threshold set to the tested values)
app.py            # the team's Streamlit app, unchanged
requirements.txt
start_server.bat  # double-click to start api.py on Windows
```

## 1. Install (once)
    pip install -r requirements.txt

## 2. Start the backend server
    python -m uvicorn api:app --host 0.0.0.0 --port 8000
(or double-click start_server.bat). The first start downloads the AI model once.

## 3. Put it on the internet with ngrok (free)
1. Sign up at https://ngrok.com and install ngrok.
2. Run once: `ngrok config add-authtoken <your token>`
3. In the ngrok dashboard, open "Domains" and claim your free static domain
   (for example `bezubaan-saathi.ngrok-free.app`).
4. Every time you demo: `ngrok http --url=bezubaan-saathi.ngrok-free.app 8000`

## 4. Tell the website where the server is
Edit `config.js` in the GitHub repo:

    window.BZ_API_BASE = "https://bezubaan-saathi.ngrok-free.app";

When the website shows "Live: connected to the BEZUBAAN Saathi server and its
database", every action goes into saathi.db.

## Show the tables updating
- VS Code: install the "SQLite Viewer" extension and open saathi.db, or
- run `streamlit run app.py` in the same folder: its queue and fleet tables read the same saathi.db.

Keep the `report_<id>.jpg` files: the ORB and AI checks compare new photos with them.
If `BZ_API_BASE` is empty, the website runs on its own in the browser.
