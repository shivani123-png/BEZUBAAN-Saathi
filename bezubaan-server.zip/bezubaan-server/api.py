"""BEZUBAAN Saathi — API server that connects the website to backend7.py.

Every action on the website calls the team's backend functions unchanged, so the
tables in saathi.db update live (the Streamlit app reads the same database).

Run (in this folder):
    pip install fastapi uvicorn python-multipart
    uvicorn api:app --host 0.0.0.0 --port 8000
"""
import base64
import contextlib
import io
import os
import sqlite3
import tempfile
from datetime import datetime

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image

from backend7 import (
    DB_NAME,
    compute_image_hash,
    dispatch_rescue_team,
    get_priority_queue,
    ingest_report_with_hash,
    initialize_database,
    load_ai_model,
    resolve_rescue_case,
    seed_mock_data,
    AI_EMBEDDING_AVAILABLE,
)

ADMIN_PASSCODE = "admin123"   # same passcode as the Streamlit app

app = FastAPI(title="BEZUBAAN Saathi API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------------------------------------------------------- start-up (same as the Streamlit app)
initialize_database()
_c = sqlite3.connect(DB_NAME)
if _c.execute("SELECT COUNT(*) FROM rescue_centers").fetchone()[0] == 0:
    seed_mock_data()
_c.close()
if AI_EMBEDDING_AVAILABLE:
    try:
        load_ai_model()          # first run downloads the model once
    except Exception as e:
        print(f"AI model not loaded yet: {e}")


def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def iso(ts: str) -> str:
    """backend timestamps are local 'YYYY-MM-DD HH:MM:SS'; the website wants ISO with time zone."""
    try:
        return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").astimezone().isoformat()
    except (TypeError, ValueError):
        return ts


def thumb(report_id: int):
    """Small preview of report_<id>.jpg (saved by backend7) for the dispatcher queue."""
    path = f"report_{report_id}.jpg"
    if not os.path.exists(path):
        return None
    try:
        im = Image.open(path).convert("RGB")
        im.thumbnail((160, 160))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=75)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:
        return None


def check_admin(passcode):
    if passcode != ADMIN_PASSCODE:
        raise HTTPException(403, "Admin passcode required.")


def state():
    get_priority_queue()  # backend7 refreshes every Pending urgency score here
    conn = db()
    try:
        reports = [dict(r) for r in conn.execute("SELECT * FROM distress_reports ORDER BY report_id")]
        centers = [dict(c) for c in conn.execute("SELECT * FROM rescue_centers ORDER BY center_id")]
        out_by_center = {}
        for r in reports:
            if r["status"] == "Dispatched" and r["assigned_center_id"]:
                out_by_center[r["assigned_center_id"]] = out_by_center.get(r["assigned_center_id"], 0) + 1
    finally:
        conn.close()
    for r in reports:
        r["timestamp"] = iso(r["timestamp"])
        r["photo"] = thumb(r["report_id"])
    for c in centers:
        c["contact_number"] = str(c["contact_number"]).strip()
        c["total_vans"] = c["available_vans"] + out_by_center.get(c["center_id"], 0)
    return {"reports": reports, "centers": centers, "ai": AI_EMBEDDING_AVAILABLE}


@app.get("/api/state")
def get_state():
    return state()


@app.post("/api/report")
async def report(
    animal_type: str = Form(...), injury_severity: int = Form(...), is_baby: int = Form(...),
    latitude: float = Form(...), longitude: float = Form(...), location_name: str = Form(...),
    photographer_id: str = Form(...), photo: UploadFile = File(...),
):
    conn = db()
    before = {r["report_id"]: (r["timestamp"], r["location_name"]) for r in conn.execute("SELECT report_id, timestamp, location_name FROM distress_reports")}
    conn.close()

    suffix = os.path.splitext(photo.filename or "")[1] or ".jpg"
    exact = None
    fd, tmp = tempfile.mkstemp(suffix=suffix)
    log = io.StringIO()
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(await photo.read())
        h = compute_image_hash(tmp)
        if h:
            c2 = db(); row = c2.execute("SELECT report_id, status FROM distress_reports WHERE image_hash = ?", (h,)).fetchone(); c2.close()
            exact = dict(row) if row else None
        with contextlib.redirect_stdout(log):   # backend7 prints which layer matched
            try:
                ok = ingest_report_with_hash(animal_type, injury_severity, is_baby, latitude, longitude,
                                             location_name.strip(), photographer_id.strip(), tmp)
            except sqlite3.IntegrityError:
                ok = False   # exact same photo as a case that is no longer Pending
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    printed = log.getvalue()
    print(printed, end="")

    s = state()
    by_id = {r["report_id"]: r for r in s["reports"]}
    if not ok:
        if exact is None and "Error" in printed:
            return {"ok": False, "reason": "unreadable", "state": s}
        return {"ok": False, "reason": "locked", "of": exact["report_id"] if exact else None,
                "status": exact["status"] if exact else "already handled", "state": s}
    new_ids = [i for i in by_id if i not in before]
    if new_ids:
        return {"ok": True, "mode": "new", "rec": by_id[max(new_ids)], "state": s}
    moved = [i for i in by_id if i in before and (by_id[i]["location_name"] != before[i][1] or by_id[i]["timestamp"] != iso(before[i][0]))]
    rid = moved[0] if moved else None
    how, points = "phash", 0
    if "AI Embedding Match" in printed:
        how = "ai"
        for line in printed.splitlines():
            if "AI Embedding Similarity" in line:
                try: points = round(float(line.split(":")[1].split()[0]) * 100)
                except Exception: pass
    elif "ORB Feature Match" in printed:
        how = "orb"
        for line in printed.splitlines():
            if "ORB Keypoint Match Count" in line:
                try: points = int(line.rsplit(":", 1)[1])
                except Exception: pass
    return {"ok": True, "mode": "updated", "how": how, "points": points, "rec": by_id.get(rid), "state": s}


@app.post("/api/dispatch/{report_id}")
def dispatch(report_id: int, x_admin_passcode: str = Header(None)):
    check_admin(x_admin_passcode)
    ok = dispatch_rescue_team(report_id)
    s = state()
    r = next((r for r in s["reports"] if r["report_id"] == report_id), None)
    if not ok:
        msg = "No ambulance vans are available at any rescue centre right now." if not any(c["available_vans"] > 0 for c in s["centers"]) else f"Report #{report_id} is already dispatched."
        return {"ok": False, "msg": msg, "state": s}
    c = next((c for c in s["centers"] if c["center_id"] == r["assigned_center_id"]), None)
    return {"ok": True, "center": c, "state": s}


@app.post("/api/resolve/{report_id}")
def resolve(report_id: int, x_admin_passcode: str = Header(None)):
    check_admin(x_admin_passcode)
    return {"ok": resolve_rescue_case(report_id), "state": state()}


@app.post("/api/reset")
def reset(x_admin_passcode: str = Header(None)):
    check_admin(x_admin_passcode)
    seed_mock_data()
    return {"ok": True, "state": state()}
