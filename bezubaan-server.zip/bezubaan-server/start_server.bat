@echo off
REM Starts the BEZUBAAN Saathi API (website -> backend7.py -> saathi.db)
cd /d "%~dp0"
python -m uvicorn api:app --host 0.0.0.0 --port 8000
